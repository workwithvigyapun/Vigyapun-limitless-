require('dotenv').config();
const express=require('express'),cors=require('cors'),helmet=require('helmet'),rateLimit=require('express-rate-limit'),nodemailer=require('nodemailer'),fs=require('fs'),path=require('path');
const app=express();
app.use(helmet({contentSecurityPolicy:false}));
app.use(cors({origin:process.env.ALLOWED_ORIGIN||true}));
app.use(express.json({limit:'20kb'}));
const lim=rateLimit({windowMs:15*60*1000,max:20});
const tx=nodemailer.createTransport({host:process.env.SMTP_HOST,port:+process.env.SMTP_PORT||465,secure:true,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}});
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

// Contact form -> email to the agency
app.post('/api/contact',lim,async(req,res)=>{
  const{name,email,message}=req.body||{};
  if(!name||!/^\S+@\S+\.\S+$/.test(email||''))return res.status(400).json({error:'Invalid input'});
  try{
    await tx.sendMail({from:process.env.SMTP_USER,to:process.env.MAIL_TO||'workwithvigyapun@gmail.com',replyTo:email,
      subject:`New enquiry from ${name}`,html:`<p><b>${esc(name)}</b> (${esc(email)})</p><p>${esc(message||'')}</p>`});
    res.json({ok:true});
  }catch(e){console.error(e);res.status(500).json({error:'Mail failed'})}
});

// "Catch the Leads" game: top-50 scores kept in a JSON file
const F=path.join(__dirname,'scores.json');
const rd=()=>{try{return JSON.parse(fs.readFileSync(F))}catch{return[]}};
app.post('/api/score',lim,(req,res)=>{
  const s=Math.min(100,Math.max(0,+req.body?.score||0));
  const a=rd();a.push({s,t:Date.now()});
  fs.writeFileSync(F,JSON.stringify(a.sort((x,y)=>y.s-x.s).slice(0,50)));res.json({ok:true});
});
app.get('/api/leaderboard',(req,res)=>res.json(rd().slice(0,10)));

app.use(express.static(path.join(__dirname,'../frontend')));
app.listen(process.env.PORT||3000,()=>console.log('Vigyapun running on port '+(process.env.PORT||3000)));
