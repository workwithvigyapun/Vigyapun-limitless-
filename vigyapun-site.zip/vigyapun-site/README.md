# Vigyapun Limitless website
frontend/index.html : the full site (HTML, CSS, JS in one file, assets embedded)
backend/ : Node.js + Express API (contact form email, game scores)

Run: cd backend && npm install && cp .env.example .env (fill SMTP_PASS) && npm start
Open http://localhost:3000
If the frontend is hosted separately, add before </head>: <script>window.API_URL="https://your-api.com"</script>
Font: add your licensed Nexa @font-face at the top of the <style> block.
